module.exports = {
  testMatch: ["<rootDir>/test/**/*.js"],
  testEnvironment: "node",
  rootDir: "",
  moduleFileExtensions: ["js"]
};
