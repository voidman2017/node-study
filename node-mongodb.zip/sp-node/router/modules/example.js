"use strict";

const Router = require("koa-router");
const controllers = require("../../controllers");
const router = new Router();

router.get("/api", controllers.example.api);

router.get('/db/:type',controllers.example.db);


module.exports = { router };
