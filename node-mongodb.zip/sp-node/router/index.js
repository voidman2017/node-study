"use strict";

const Router = require("koa-router");
const exampleRouter = require('./modules/example');

const router = new Router();

router.use('/example', exampleRouter)



module.exports = { router };
