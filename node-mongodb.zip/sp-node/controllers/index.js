"use strict";

const fs = require("fs");

const fileNames = fs
  .readdirSync(__dirname)
  .filter(fileName => fileName !== "index.js")
  .filter(fileName => fileName.toLowerCase().endsWith(".js"));

const controllers = {};

fileNames.forEach(fileName => {
  const controller = require(`./${fileName}`);
  const key = rmFileType(fileName);
  controllers[key] = controller;
});

function rmFileType(fileName) {
  return fileName.replace(/\.js/, "");
}

module.exports = controllers;
