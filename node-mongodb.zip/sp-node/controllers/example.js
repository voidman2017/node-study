"use strict";
const ModelDb = require('../lib/db');

const api = async (ctx, next) => {
  ctx.result = "";
  ctx.msg = "请求成功";
  return next();
};

const db = async (ctx, next) => {
  const { query } = ctx;
  const {type} = ctx.params;
  let data = await ModelDb[type](query)
  ctx.body = data
}

module.exports = { api, db };
