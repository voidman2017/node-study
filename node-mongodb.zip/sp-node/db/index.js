const mongoose = require('./db')
const Schema = mongoose.Schema;

const user = new Schema({
    name: String,
    age: Number,
    sex: String
}, { versionKey: false });

const MyModel = mongoose.model('user', user);

class Mongodb {
    constructor() {
    }
    // 查询
    query(params) {
        return new Promise((resolve, reject) => {
            MyModel.find(params, (err, res) => {
                if (err) {
                    reject(err)
                }
                resolve(res)
            })
        })
    }
    // 保存
    save(data) {
        const m = new MyModel(data)
        return new Promise((resolve, reject) => {
            m.save((err, res) => {
                if (err) {
                    reject(err)
                }
                resolve(res)
                console.log(res)
            })
        })

    }
    create(data) {
        return new Promise((resolve, reject) => {
            MyModel.create(data, (err, res) => {
                if (err) {
                    reject(err)
                }
                resolve(res)
            })
        })
    }
    // 删除
    delete(data) {
        return new Promise((resolve, reject) => {
            MyModel.remove(data, (err, res) => {
                if (err) {
                    reject(err)
                }
                resolve(res)
            })
        })
    }
    //更新
    update(condition) {
        var updates = { name: "tony" };//将用户名更新为“tony”
        return new Promise((resolve, reject) => {
            MyModel.update(condition, updates, (err, res) => {
                if (err) {
                    reject(err)
                }
                resolve(res)
            })
        })
    }

}

module.exports = new Mongodb()