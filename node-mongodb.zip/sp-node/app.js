"use strict";

const Koa = require("koa");
const path = require('path');
const { loggerMiddleware } = require("./middleware/logger");
const bodyParser = require("koa-bodyparser");
const koaStatic = require("koa-static");


const {
  errorMiddleware,
  responseMiddleware
} = require("./middleware/response");
const helmet = require("koa-helmet");
const cors = require("koa2-cors");
const { corsConfig } = require("./middleware/cors");
const { router } = require("./router");

const app = new Koa();


app.use(koaStatic(path.join(__dirname, "assets"))); //静态资源中间件
app.use(loggerMiddleware);
app.use(bodyParser());
app.use(errorMiddleware);
app.use(helmet());
app.use(cors(corsConfig));
app.use(router.routes(), router.allowedMethods());
app.use(responseMiddleware);

module.exports = app;
