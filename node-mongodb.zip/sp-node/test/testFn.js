test("matchers", () => {
  const a = {
    hello: "jest"
  };
  const b = {
    hello: "jest"
  };
  expect(a).toEqual(b);
});
