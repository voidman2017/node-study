const app = require("../app.js");
const supertest = require("supertest");
const assert = require("assert");

let server;
let request;

afterEach(() => {
  server.close();
});
beforeEach(() => {
  server = app.listen(3000);
  request = supertest(server);
});

test("GET /example/api", async () => {
  await request
    .get("/example/api")
    .set("Accept", "application/json")
    .expect(200)
    .expect("Content-Type", /json/)
    .then(response => {
      assert.deepStrictEqual(response.body,  {"code": 200, "data": "", "msg": "请求成功"});
    });
});
